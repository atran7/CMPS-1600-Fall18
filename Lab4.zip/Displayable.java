/**
 * Display interface helps with readability of shape information
 */
public interface Displayable
{
    void display();
}
